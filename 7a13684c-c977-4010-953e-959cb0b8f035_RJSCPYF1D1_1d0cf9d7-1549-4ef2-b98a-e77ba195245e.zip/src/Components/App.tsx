import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import TransactionsOverview from './components/TransactionsOverview';
import TransactionDetails from './components/TransactionDetails';
import TransactionStatusCheck from './components/TransactionStatusCheck';

function App() {
    return (
        <Router>
            <div className="App">
                <h1>School Payments Dashboard</h1>
                <Routes>
                    <Route path="/" element={<TransactionsOverview />} />
                    <Route path="/transaction-details" element={<TransactionDetails />} />
                    <Route path="/status-check" element={<TransactionStatusCheck />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;
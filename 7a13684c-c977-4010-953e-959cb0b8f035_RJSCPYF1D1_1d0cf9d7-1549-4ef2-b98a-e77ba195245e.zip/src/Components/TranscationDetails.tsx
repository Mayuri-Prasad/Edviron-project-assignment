import React, {useEffect, useState} from 'react'
import axios from 'axios'

interface Transaction {
  collect_id: string
  gateway: string
  order_amount: number
  transaction_amount: number
  status: string
  custom_order_id: string
}

const TransactionDetails: React.FC = () => {
  const [schoolId, setSchoolId] = useState('')
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchTransactionsBySchool = async () => {
    if (!schoolId) return

    try {
      const response = await axios.get(`/transactions?school_id=${schoolId}`)
      setTransactions(response.data)
    } catch (err) {
      setError('Failed to fetch transactions for this school')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTransactionsBySchool()
  }, [schoolId])

  if (loading) return <div>Loading...</div>
  if (error) return <div>{error}</div>

  return (
    <div>
      <h1>Transaction Details by School</h1>
      <input
        type="text"
        placeholder="Enter School ID"
        value={schoolId}
        onChange={e => setSchoolId(e.target.value)}
      />
      <button onClick={fetchTransactionsBySchool}>Fetch Transactions</button>
      <table>
        <thead>
          <tr>
            <th>Collect ID</th>
            <th>Gateway</th>
            <th>Order Amount</th>
            <th>Transaction Amount</th>
            <th>Status</th>
            <th>Custom Order ID</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map(transaction => (
            <tr key={transaction.collect_id}>
              <td>{transaction.collect_id}</td>
              <td>{transaction.gateway}</td>
              <td>{transaction.order_amount}</td>
              <td>{transaction.transaction_amount}</td>
              <td>{transaction.status}</td>
              <td>{transaction.custom_order_id}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default TransactionDetails

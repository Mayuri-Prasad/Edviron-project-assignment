import React, {useState} from 'react'
import axios from 'axios'

const TransactionStatusCheck: React.FC = () => {
  const [customOrderId, setCustomOrderId] = useState('')
  const [status, setStatus] = useState('')
  const [error, setError] = useState('')

  const checkStatus = async () => {
    if (!customOrderId) return

    try {
      const response = await axios.get(
        `/check-status?custom_order_id=${customOrderId}`,
      )
      setStatus(response.data.status)
    } catch (err) {
      setError('Failed to fetch transaction status')
    }
  }

  return (
    <div>
      <h1>Transaction Status Check</h1>
      <input
        type="text"
        placeholder="Enter Custom Order ID"
        value={customOrderId}
        onChange={e => setCustomOrderId(e.target.value)}
      />
      <button onClick={checkStatus}>Check Status</button>
      {status && <div>Status: {status}</div>}
      {error && <div>{error}</div>}
    </div>
  )
}

export default TransactionStatusCheck

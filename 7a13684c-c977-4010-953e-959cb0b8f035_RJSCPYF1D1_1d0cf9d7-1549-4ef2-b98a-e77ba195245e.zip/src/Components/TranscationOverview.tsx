import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Transaction {
    collect_id: string;
    school_id: string;
    gateway: string;
    order_amount: number;
    transaction_amount: number;
    status: string;
    custom_order_id: string;
}

const TransactionsOverview: React.FC = () => {
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [statusFilter, setStatusFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchTransactions = async () => {
            try {
                const response = await axios.get('/transactions');
                setTransactions(response.data);
            } catch (err) {
                setError('Failed to fetch transactions');
            } finally {
                setLoading(false);
            }
        };

        fetchTransactions();
    }, []);

    const filteredTransactions = transactions.filter(transaction => {
        return (
            (statusFilter ? transaction.status === statusFilter : true) &&
            (searchTerm ? transaction.custom_order_id.includes(searchTerm) : true)
        );
    });

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div>
            <h1>Transactions Overview</h1>
            <select onChange={(e) => setStatusFilter(e.target.value)} value={statusFilter}>
                <option value="">All Statuses</option>
                <option value="Success">Success</option>
                <option value="Pending">Pending</option>
                <option value="Failed">Failed</option>
            </select>
            <input
                type="text"
                placeholder="Search by Custom Order ID"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            <table>
                <thead>
                    <tr>
                        <th>Collect ID</th>
                        <th>School ID</th>
                        <th>Gateway</th>
                        <th>Order Amount</th>
                        <th>Transaction Amount</th>
                        <th>Status</th>
                        <th>Custom Order ID</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredTransactions.map(transaction => (
                        <tr key={transaction.collect_id}>
                            <td>{transaction.collect_id}</td>
                            <td>{transaction.school_id}</td>
                            <td>{transaction.gateway}</td>
                            <td>{transaction.order_amount}</td>
                            <td>{transaction.transaction_amount}</td>
                            <td>{transaction.status}</td>
                            <td>{transaction.custom_order_id}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TransactionsOverview;
